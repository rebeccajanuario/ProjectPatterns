/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Aluno
 */
public class Email extends Assinante {
    public static void enviarEmail(String nome, String email,String mensagem)
    {
        System.out.println("'----------------------------------------\n");
        System.out.println("Email eviado para  " + nome()+ email());
        System.out.println("Mensagem : "+ mensagem+ "\n");
    }
}
