/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Aluno
 */
public class Newsletter implements Subject{

    
   private List<Observer> observers;
   private List<String> mensagens;
    
   public Newsletter(){
       observers = new ArrayList<>();
       mensagens = new ArrayList<>();
       
   }
           
    @Override
    public void registerObserver(Observer observer) {
        this.observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        this.observers.remove(observer);
       
    }

    @Override
    public void notifyObservers() {
        for(Observer observer : observers){
            int lastIndex = mensagens.size() - 1;
            observer.update(mensagens.get(lastIndex));
        }
    }
    
    public void addMensagem(String message){
        this.mensagens.add(message);
        this.notifyObservers();
    }
    
}
