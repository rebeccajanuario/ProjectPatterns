/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Aluno
 */
public class Teste {
    
    public static void main(String[] args) {
        Newsletter newsletter = new Newsletter();
        
        Funcionario f1 = new Funcionario("Func 1", "func1@email.com", newsletter);
        
        Cliente c1 = new Cliente("Cliente 1", "cliente1@email.com", newsletter);
        
        newsletter.addMensagem("Primeira mensagem");
        
        newsletter.removeObserver(f1);
        
        newsletter.addMensagem("Segunda mensagem");
    }
    
    
    
}
