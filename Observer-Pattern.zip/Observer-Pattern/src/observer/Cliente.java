/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Aluno
 */
public class Cliente extends Assinante implements Observer{
    
    
    public Cliente(String nome, String email, Subject subject){
        super(nome, email, subject);
        this.subject.registerObserver(this);
    }
    
    @Override
    public void update(String mensagem){
        Email.enviarEmail(nome,email, mensagem);
    }
    
  

    
    
    
    
}
