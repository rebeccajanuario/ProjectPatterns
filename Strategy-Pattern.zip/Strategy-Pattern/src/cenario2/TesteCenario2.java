/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario2;

/**
 *
 * @author Aluno
 */
public class TesteCenario2 {
     public static void main(String[]args){
        //criando um pedido do setor de eletronicos
        Pedido pedido = new PedidosEletronicos();
        
        //setar valor do pedido
        pedido.setValor(100);
        
        //Calcular frete comum 
        System.out.println("Frete comum: R$" +pedido.calcularFreteComum());
        //Calcular frete expresso
        System.out.println("Frete expresso: R$" +pedido.calcularFreteExpresso());
        
    }
    
}
