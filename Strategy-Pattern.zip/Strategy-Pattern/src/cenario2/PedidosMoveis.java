/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario2;

/**
 *
 * @author Aluno
 */
public class PedidosMoveis extends Pedido{
    private String nomeSetor;

    public PedidosMoveis(){
        nomeSetor = "Móveis";
    }
    
    public String getNomeSetor() {
        return nomeSetor;
    }

    public void setNomeSetor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }

    @Override
    public double calcularFreteComum() {
        return valor * 0.05;
    }

    @Override
    public double calcularFreteExpresso() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
}
