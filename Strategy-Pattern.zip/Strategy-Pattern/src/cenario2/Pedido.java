/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario2;


/**
 *
 * @author Aluno
 */
public abstract class Pedido {
    protected double valor;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    //implementação desse metodo passa a ser a responsabilidade da subclasse 
    public abstract double calcularFreteComum();
    public abstract double calcularFreteExpresso();
    /*
    public double calcularFreteComum(){
        // custa 5%
        return valor * 0.05;
    }
    
    
    public double calcularFreteExpresso(){
        //custa 10%
        return valor * 0.1;
    }
    */
    
}
