/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario1;

/**
 *
 * @author Aluno
 */
public class TesteCenario1 {
    public static void main(String[]args){
        //criando um pedido
        Pedido pedido = new Pedido();
        
        //setar valor do pedido
        pedido.setValor(100);
        
        //Calcular frete comum 
        System.out.println("Frete comum: R$" +pedido.calcularFreteComum());
        //Calcular frete expresso
        System.out.println("Frete expresso: R$" +pedido.calcularFreteExpresso());
        
    }
}
