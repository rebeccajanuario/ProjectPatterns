/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario1;

/**
 *
 * @author Aluno
 */
public class Pedido {
    private double valor;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    public double calcularFreteComum(){
        // custa 5%
        return valor * 0.05;
    }
    
    public double calcularFreteExpresso(){
        //custa 10%
        return valor * 0.1;
    }
    
}
