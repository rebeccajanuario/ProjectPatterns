/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cenario3;

/**
 *
 * @author Aluno
 */
public interface Frete {
    //recebe o valor do pedido que é utilizado no calculo do frete 
    public double calcula(double valorPedido);
}
