/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario3;

/**
 *
 * @author Aluno
 */
public class TesteCenario3 {
    public static void main(String[] args) {
        //criação de tipos de frete
        Frete freteComum =  new FreteComum();
        Frete freteExpresso = new FreteExpresso();
        
        Pedido pedido = new PedidosEletronicos();
        
        //atribuição de valor
        pedido.setValor(1000);
        //tipo do frete escolhido
        pedido.setTipoFrete(freteComum);
        
        System.out.println("Frete Comum - Eletrônicos: R$" +pedido.calculaFrete());
        
        //no mesmo pedido pode trocar o tipo de frete
        pedido.setTipoFrete(freteExpresso);
        
         System.out.println("Frete Expresso - Eletrônicos: R$" +pedido.calculaFrete());
         
         
         
    }
}
