/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cenario3;


/**
 *
 * @author Aluno
 */
public class PedidosEletronicos extends Pedido {
    private String nomeSetor;

    public PedidosEletronicos(){
        nomeSetor = "Eletrônicos";
    }
    
    public String getNomeSetor() {
        return nomeSetor;
    }

    public void setNomeSetor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }
/*
    @Override
    public double calcularFreteComum() {
         return valor * 0.05;
    }

    @Override
    public double calcularFreteExpresso() {
        return valor * 0.1;
       
    }
*/
    
    
    
}
