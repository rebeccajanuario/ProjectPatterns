/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

/**
 *
 * @author Aluno
 */
public class Teste {
    public static void main(String[] args) {
        Gateway g = new Gateway();
    
        
        Pagamento pCartaoCredito = new PagamentoCredito(1000, g);
        Pagamento pDebito = new PagamentoDebito(1000, g);
        Pagamento pDinheiro = new PagamentoDinheiro(1000, g);
        
        pCartaoCredito.realizarCobranca();
        pDebito.realizarCobranca();
        pDinheiro.realizarCobranca();
    }
    
    
}
