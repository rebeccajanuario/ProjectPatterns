/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

/**
 *
 * @author Aluno
 */
public class PagamentoCredito extends Pagamento{

    public PagamentoCredito(double valor, Gateway gateway) {
        super(valor, gateway);
    }
  

    
    //calcula taxa
    @Override
    public double calcularTaxa(){
        return valor *  0.05; 
    }
    
    //calcula desconto
    @Override
    public double calcularDesconto(){
        if(valor > 300){
            return valor *0.02;
        }else{
            return 0;
        }
    }
    
}
