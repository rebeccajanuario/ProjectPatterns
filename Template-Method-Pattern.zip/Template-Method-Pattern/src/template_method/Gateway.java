/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

import java.util.Random;

/**
 *
 * @author Aluno
 */
public class Gateway {
    public boolean cobrar(double valor){
        System.out.println("R$" + valor);
        Random r = new Random();
        int ind = r.nextInt(1);
        boolean[] resposta = {true, false};
        return resposta[ind];
    }
}
