/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

/**
 *
 * @author Aluno
 */
public class PagamentoDinheiro  extends Pagamento {

    public PagamentoDinheiro(double valor, Gateway gateway) {
        super(valor, gateway);
    }

   


    
    //calcula desconto
    @Override
    public double calcularDesconto(){
        return valor *0.1;
    }
    
    
}
