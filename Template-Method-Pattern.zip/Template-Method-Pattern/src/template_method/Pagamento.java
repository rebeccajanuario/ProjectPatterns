/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

/**
 *
 * @author Aluno
 */
public abstract class Pagamento {
    
    protected double valor;
    protected Gateway gateway;
    
        
    public Pagamento(double valor, Gateway gateway){
        this.valor = valor;
        this.gateway = gateway;
    }
    
    public abstract double calcularDesconto();
    
    public double calcularTaxa(){
        return 0; 
    }
       
     public boolean realizarCobranca(){
        double valorFinal = valor + calcularTaxa()-calcularDesconto();
        return gateway.cobrar(valorFinal);
    }
    
    
    
    
}
