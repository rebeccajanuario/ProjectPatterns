/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package template_method;

/**
 *
 * @author Aluno
 */
public class PagamentoDebito  extends Pagamento{

    public PagamentoDebito(double valor, Gateway gateway) {
        super(valor, gateway);
    }


  
    //calcula taxa
    @Override
    public double calcularTaxa(){
        return 4; 
    }
    
    //calcula desconto
    @Override
    public double calcularDesconto(){
        return valor *0.05;
    }
    
    
}
